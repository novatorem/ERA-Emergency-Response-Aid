Dellis, Ng, ngdellis

Abdulla, Haji, binhajia
